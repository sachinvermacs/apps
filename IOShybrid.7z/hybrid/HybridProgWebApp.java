package com.connectivity.testsIos.hybrid;

import com.connectivity.core.BasicIosAppium;
import com.connectivity.retry.Retry;
import com.connectivity.testNgSuiteGenerator.DeviceData;
import com.connectivity.testsIos.testAppsProperties.Snapwat;
import com.connectivity.utils.RunMode;
import com.connectivity.utils.TestUtils;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;


public class HybridProgWebApp extends BasicIosAppium {

    //private static final String appName = "Smaller Pics";

    //private static final String SITE_URL = "http://www.smaller-pictures.appspot.com";
    private static final String SITE_URL = "https://snapw.at/";

    //private static final String PICKER_BTN_XPATH = "//*[@id='labelForPicker']";
    private static final String LINK_ABOUT = "//*[@id='link-about']";
    private static final String BACK_BTN = "//*[@id='link-home']";

    private static final String TAKE_PHOTO_BTN = "//*[@label='Take Photo or Video']";
    private static final String CANCEL_BTN = "//*[@label='Cancel']";

    private static final String URL_ADDRESS_INPUT_XPATH = "//*[@label='Address']";
    private static final String REFRESH_BROWSER_XPATH = "//*[@label='reload']";
    private static final String REFRESH_BROWSER_IOS14_XPATH = "//*[@label='Reload']";
    private static final String GO_BTN = "//*[@label='Go']";
    private static final String GO_BTN_IOS_14 = "//*[@label='go']";
    private static final String SHARE_BTN_XPATH = "//*[@label='Share']";
    private static final String ADD_TO_HOME_BTN_XPATH = "//*[@label='Add to Home Screen']";
    private static final String ADD_TO_HOME_BTN_IOS14_XPATH = "//XCUIElementTypeButton[@label='Add to Home Screen']";
    private static final String ADD_BTN_XPATH = "//*[@label='Add']";



    private WebElement expElement = null;

    private static boolean isInstrumented = true;   // default test param value

    @BeforeClass(alwaysRun = true)
    @Parameters({"deviceId", "automationName", "autoInstrument"})
    public void beforeClass(@Optional("") String deviceId, @Optional("Appium") String automationName,  @Optional("false") String autoInstrument, ITestContext context) throws MalformedURLException {

        TestUtils.validateDeviceOsVersionCompatibilityAndSkipTest(11.3);

        if(getDevice().getOsVersion().startsWith("13.")){
            TestUtils.skipTest("The appium web automation is not supported on iOS 13 Beta yet, so skipping test...");
        }
        if(getDevice().getOsVersion().startsWith("14.")){
            TestUtils.skipTest("The appium web automation is not supported on iOS 13 Beta yet, so skipping test...");
        }
        if(cloud.contains("covid19")){
            TestUtils.skipTest("Update the test for new devices. Snapwat progressive web cannot be installed");
        }

        TestUtils.skipTestByModel("iPad", "Test is blocked by ticket https://perfectomobile.atlassian.net/browse/NP-33933");

        if (!Boolean.valueOf(autoInstrument)) isInstrumented = false;

        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("bundleId", Snapwat.APP_BUNDLE_ID);
        capabilities.setCapability("automationName", automationName);
        capabilities.setCapability("deviceName", deviceId);
        capabilities.setCapability("browserName", "mobileOS");

        createIosDriver(capabilities);

        getDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        getDriver().manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);

    }

    @Test(groups = {RunMode.PROGRESSIVE_WEB_APP, RunMode.PREPROD})
    public void basicProgressiveWebAppTest() {

        boolean isInstalled = false;

        try {
            openPWA();
            isInstalled = true;
        } catch (WebDriverException we) {
            we.printStackTrace();
        }

        if (!isInstalled) installAndOpenPWA();

        // press on Picker btn (WEB)
        getDriver().context("WEBVIEW");
        //getDriver().findElementByXPath(PICKER_BTN_XPATH).click(); // blocked by ticket https://perfectomobile.atlassian.net/browse/NP-33932
        TestUtils.waitSeconds(2);
        getDriver().findElementByXPath(LINK_ABOUT).click();
        TestUtils.waitSeconds(2);
        getDriver().findElementByXPath(BACK_BTN).click();

        /*// check action element found (NATIVE) // blocked by ticket https://perfectomobile.atlassian.net/browse/NP-33932
        getDriver().context("NATIVE_APP");
        getDriver().findElementByXPath(TAKE_PHOTO_BTN);

        // press Cancel (NATIVE)
        getDriver().findElementByXPath(CANCEL_BTN).click();
        TestUtils.waitSeconds(2);*/

        // close PWA
        closePWA();

    }

    private void installAndOpenPWA() {

        HashMap<String, String> params = new HashMap<>();

        // Navigate to site with PWA support
        TestUtils.waitSeconds(2);
        getDriver().launchApp();
        TestUtils.waitSeconds(2);
        try {
            getDriver().findElementByXPath(REFRESH_BROWSER_XPATH).click();
            TestUtils.waitSeconds(2);
        } catch (WebDriverException we){

            we.printStackTrace();
        }

        //for ios 14
        try {
            getDriver().findElementByXPath(REFRESH_BROWSER_IOS14_XPATH).click();
            TestUtils.waitSeconds(2);
        } catch (WebDriverException we){

            we.printStackTrace();
        }
        getDriver().findElementByXPath(URL_ADDRESS_INPUT_XPATH).click();
        TestUtils.waitSeconds(2);
        getDriver().findElementByXPath(URL_ADDRESS_INPUT_XPATH).clear();
        TestUtils.waitSeconds(2);
        getDriver().findElementByXPath(URL_ADDRESS_INPUT_XPATH).sendKeys(SITE_URL);
        TestUtils.waitSeconds(2);
        try
        {
            getDriver().findElementByXPath(GO_BTN).click();
        }
        catch (Exception ex)
        {
            getDriver().findElementByXPath(GO_BTN_IOS_14).click();
        }
        TestUtils.waitSeconds(2);
        // Open share options menu bar
        getDriver().context("NATIVE_APP");
        getDriver().findElementByXPath(SHARE_BTN_XPATH).click();
        TestUtils.waitSeconds(3);
        WebElement button = null;
        try
        {
            // Press on Add to Home IOS 14
            button = getDriver().findElementByXPath(ADD_TO_HOME_BTN_XPATH);
        }
        catch (Exception ex)
        {
            // Press on Add to Home IOS <14
            params.put("start", "60%,80%");
            params.put("end", "10%,80%");
            params.put("duration", "3");
            getDriver().executeScript("mobile:touch:swipe", params);
            TestUtils.waitSeconds(3);
            button = getDriver().findElementByXPath(ADD_TO_HOME_BTN_XPATH);
        }

        TestUtils.waitSeconds(3);
        button.click();
        TestUtils.waitSeconds(3);
        getDriver().findElementByXPath(ADD_BTN_XPATH).click();
        TestUtils.waitSeconds(3);
        TestUtils.clickHomeButtonIOS(getDriver());
        TestUtils.waitSeconds(3);
        openPWA();

    }

    private void openPWA() {

        HashMap<String, String> params = new HashMap<>();
        params.put("displayName", Snapwat.APP_NAME);
        getDriver().executeScript("mobile:pwa:start", params);
        TestUtils.waitSeconds(2);
    }

    private void closePWA() {
        getDriver().executeScript("mobile:pwa:stop");
        TestUtils.waitSeconds(2);
    }



}
