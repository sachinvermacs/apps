package com.connectivity.testsIos.hybrid;

import com.connectivity.utils.TestUtils;
import org.testng.Assert;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

public class HybridAppiumFlow extends BaseHybrid {

    @Override
    protected void verifyFirstWebView() {

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "APPIUM FLOW: Search webview 1, do context switch and verify web element");
        Set<Map<String, Object>> contexts = getDriver().getContextHandles();
        Optional<Map<String, Object>> webView;
        webView = contexts.stream().filter(c -> !c.get("id").equals("NATIVE_APP"))
                .filter(c -> c.get("title").equals(TITLE_EXPECTED_WEB_1))
                .findFirst();

        if (webView.isPresent()) {
            getDriver().context(webView.get().get("id").toString());
            TestUtils.waitSeconds(1);
            expElement = getDriver().findElementByXPath(XPATH_EXPECTED_WEB_1);
            Assert.assertEquals(expElement.getText(), "OK", "Label of web element in WEBVIEW 1 not found");
        } else {
            Assert.fail("Failed to find WEBVIEW 1 by TITLE: " + TITLE_EXPECTED_WEB_1);
        }

    }

    @Override
    protected void verifySecondWebView() {

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "APPIUM FLOW: Search webview 2, do context switch and verify web element");
        Set<Map<String, Object>> contexts;
        Optional<Map<String, Object>> webView;
        contexts = getDriver().getContextHandles();
        webView = contexts.stream().filter(c -> !c.get("id").equals("NATIVE_APP"))
                .filter(c -> c.get("url").equals(URL_2))
                .findFirst();

        if (webView.isPresent()) {
            getDriver().context(webView.get().get("id").toString());
            TestUtils.waitSeconds(1);
            expElement = getDriver().findElementByXPath(XPATH_EXPECTED_WEB_2);
            Assert.assertEquals(expElement.getText(), "article", "Label of web element in WEBVIEW 2 not found");
        } else {
            Assert.fail("Failed to find WEBVIEW 2 by URL: " + URL_1);
        }

    }


    @Override
    protected Boolean isAppiumFlow() {
        return true;
    }


}
