package com.connectivity.testsIos.hybrid;

import com.connectivity.utils.TestUtils;
import org.testng.Assert;

public class HybridSafariViewControllerPerfectoFlow extends BaseSafariViewController {

    @Override
    public void verifyWebViewSVC() {

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "PERFECTO FLOW: Search SVC webview, do context switch and verify web element");
        getDriver().context("WEBVIEW_1");
        getDriver().findElementByLinkText(LINK_IN_SAFARI_VIEW_FORM).click();
        TestUtils.waitSeconds(3);
        getDriver().findElementByLinkText(LINK_IN_SAFARI_VIEW_ELEM).click();
        TestUtils.waitSeconds(3);
        Assert.assertEquals(getElementByXPath(XPATH_EXPECTED_ELEMENT_WEB).getText(), LABEL_EXPECTED, "Label of element in WEBVIEW context not found");

    }

    @Override
    protected Boolean isAppiumFlow() {
        return false;
    }


}
