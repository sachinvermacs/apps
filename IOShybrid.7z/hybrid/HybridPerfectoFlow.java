package com.connectivity.testsIos.hybrid;

import com.connectivity.utils.TestUtils;
import org.testng.Assert;

public class HybridPerfectoFlow extends BaseHybrid {

    @Override
    protected void verifyFirstWebView() {

        if (isInstrumented) {
            logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "PERFECTO FLOW: Search webview 1, do context switch and verify web element");
            getDriver().context("WEBVIEW_1");
            TestUtils.waitSeconds(5);
            expElement = getDriver().findElementByXPath(XPATH_EXPECTED_WEB_1);

        } else {
            logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Verify element found by native spy in webview 1");
            expElement = getDriver().findElementByXPath(XPATH_EXPECTED_NATIVE_1);
        }

        Assert.assertEquals(expElement.getText(), "OK", "Label of element in webview 1 not found");

    }

    @Override
    protected void verifySecondWebView() {

        if (isInstrumented) {
            logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "PERFECTO FLOW: Search webview 2, do context switch and verify web element");
            getDriver().context("WEBVIEW_2");
            TestUtils.waitSeconds(5);
            expElement = getDriver().findElementByXPath(XPATH_EXPECTED_WEB_2);

        } else {
            logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Verify element found by native spy in webview 2");
            expElement = getDriver().findElementByXPath(XPATH_EXPECTED_NATIVE_2);
        }

        Assert.assertEquals(expElement.getText(), "article", "Label of element in webview 2 not found");

    }

    @Override
    protected Boolean isAppiumFlow() {
        return false;
    }


}





