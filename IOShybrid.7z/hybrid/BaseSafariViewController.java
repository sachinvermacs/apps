package com.connectivity.testsIos.hybrid;

import com.connectivity.core.BasicIosAppium;
import com.connectivity.retry.Retry;
import com.connectivity.testsIos.testAppsProperties.PmTestX;
import com.connectivity.utils.RunMode;
import com.connectivity.utils.TestUtils;
import io.appium.java_client.ios.IOSElement;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;


public abstract class BaseSafariViewController extends BasicIosAppium {

    protected static final String XPATH_SVC_HOME_VIEW_BTN = "//*[@name='TEST SAFARI VC']";
    protected static final String XPATH_OPEN_SVC_VIEW_BTN = "//*[@name='Safari VC']";
    protected static final String XPATH_BACK_BTN = "//*[@name='BACK']";
    protected static final String LINK_IN_SAFARI_VIEW_FORM = "Form/";
    protected static final String LINK_IN_SAFARI_VIEW_ELEM = "form.html";
    protected static final String XPATH_EXPECTED_ELEMENT_WEB = "//html[1]/body[1]/header[1]/h1[1]";
    protected static final String TITLE_EXPECTED_WEB = "Index of /ConnectivityTests";
    protected static final String LABEL_EXPECTED = "Set Control Test P2";
    protected static final String XPATH_EXPECTED_ELEMENT_NATIVE = "//*[@label='Set Control Test P2']";
    protected static final String XPATH_DONE_BTN = "//*[@name='Done']";

    @BeforeClass(alwaysRun = true)
    @Parameters({"deviceId", "automationName", "autoInstrument"})
    public void beforeClass(@Optional("") String deviceId, @Optional("Appium") String automationName, @Optional("false") String autoInstrument, ITestContext context) throws MalformedURLException {

        // add retry for tests using web navigation
        for (ITestNGMethod method : context.getAllTestMethods()) {
            method.setRetryAnalyzer(new Retry());
        }

        /*if (getDevice().getOsVersion().startsWith("13.") && isAppiumFlow()) {
            TestUtils.skipTest("Pure Appium v1.14 does not support web automation on IOS13, so skipping test...");
        }*/

        DesiredCapabilities capabilities = new DesiredCapabilities();

        if (PmTestX.APP_REPO_LOCATION != null) {
            capabilities.setCapability("app", PmTestX.APP_REPO_LOCATION);
        }
        capabilities.setCapability("bundleId", PmTestX.APP_BUNDLE_ID);
        capabilities.setCapability("autoInstrument", autoInstrument);
        capabilities.setCapability("automationName", automationName);
        capabilities.setCapability("deviceName", deviceId);

        if (isAppiumFlow()) {
            capabilities.setCapability("useAppiumForHybrid", true);
            capabilities.setCapability("fullContextList", true);
            capabilities.setCapability("iOSResign", true);
            //capabilities.setCapability("additionalWebviewBundleIds", Arrays.asList("com.perfectotest.PMTestIphoneX", "process-SafariViewService"));
        } else if (TestUtils.validateDeviceOsVersionCompatibility(12.2)) {
            capabilities.setCapability("iOSResign", true);
        }

        createIosDriver(capabilities, PmTestX.APP_NAME);

        getDriver().manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
        getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        if (!TestUtils.isDeviceUsingXCUITest(getDriver()))
            TestUtils.skipTest("Test app not supported on devices using UIAutomation framework");

        /*if (isAppiumFlow() && getDevice().getOsVersion().startsWith("10") && TestUtils.isDeviceUsingXCUITest(getDriver())) {
            TestUtils.skipTest("The pure appium web automation is not working on ios10-PMD devices due to ticket: https://perfectomobile.atlassian.net/browse/NP-41070");
        }*/

    }

    @Test(groups = {RunMode.HYBRID, RunMode.SANITY})
    public void basicFlowSafariViewControllerAppium() {

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Do context switch to NATIVE_APP");
        getDriver().context("NATIVE_APP");
        TestUtils.waitSeconds(1);

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Enter app view with Safari View Controller");
        TestUtils.waitSeconds(10);
        getElementByXPath(XPATH_SVC_HOME_VIEW_BTN).click();
        TestUtils.waitSeconds(2);
        getElementByXPath(XPATH_OPEN_SVC_VIEW_BTN).click();
        TestUtils.waitSeconds(15);

        verifyWebViewSVC();

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Do context switch to NATIVE_APP and verify web element by native spy");
        getDriver().context("NATIVE_APP");
        TestUtils.waitSeconds(1);

        Assert.assertEquals(getElementByXPath(XPATH_EXPECTED_ELEMENT_NATIVE).getAttribute("label"), LABEL_EXPECTED, "Label of element in NATIVE context not found");

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Close Safari Web View");
        getElementByXPath(XPATH_DONE_BTN).click();
        TestUtils.waitSeconds(1);

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Navigate back to app home view");
        getElementByXPath(XPATH_BACK_BTN).click();
        TestUtils.waitSeconds(1);

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Verify app home view loaded");
        Assert.assertTrue(getElementByXPath(XPATH_SVC_HOME_VIEW_BTN) != null, "App home view not loaded");


    }

    protected abstract void verifyWebViewSVC();

    protected abstract Boolean isAppiumFlow();

    protected IOSElement getElementByXPath(String xPath) {

        IOSElement expElement = null;

        try {
            expElement = (IOSElement) getDriver().findElementByXPath(xPath);
        } catch (WebDriverException wex) {
            wex.printStackTrace();
            logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Element not found by xpath: " + xPath);
        }
        return expElement;
    }


}
