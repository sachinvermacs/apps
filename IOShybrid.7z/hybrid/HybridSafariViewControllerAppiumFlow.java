package com.connectivity.testsIos.hybrid;

import com.connectivity.utils.TestUtils;
import org.testng.Assert;

import java.util.Map;
import java.util.Set;
import java.util.Optional;

public class HybridSafariViewControllerAppiumFlow extends BaseSafariViewController {

    @Override
    public void verifyWebViewSVC() {

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "APPIUM FLOW: Search SVC webview, do context switch and verify web element");
        Set<Map<String, Object>> contexts = getDriver().getContextHandles();
        Optional<Map<String, Object>> webView;
        webView = contexts.stream().filter(c -> !c.get("id").equals("NATIVE_APP"))
                .filter(c -> c.get("title").equals(TITLE_EXPECTED_WEB))
                .findFirst();

        if (webView.isPresent()) {
            getDriver().context(webView.get().get("id").toString());
            TestUtils.waitSeconds(3);
            getDriver().findElementByLinkText(LINK_IN_SAFARI_VIEW_FORM).click();
            TestUtils.waitSeconds(3);
            getDriver().findElementByLinkText(LINK_IN_SAFARI_VIEW_ELEM).click();
            TestUtils.waitSeconds(3);
            Assert.assertEquals(getElementByXPath(XPATH_EXPECTED_ELEMENT_WEB).getText(), LABEL_EXPECTED, "Label of element in WEBVIEW context not found");
        } else {
            Assert.fail("Failed to find WEBVIEW by TITLE: " + TITLE_EXPECTED_WEB);
        }


    }

    @Override
    protected Boolean isAppiumFlow() {
        return true;
    }


}
