package com.connectivity.testsIos.hybrid;

import com.connectivity.core.BasicIosAppium;
import com.connectivity.retry.Retry;
import com.connectivity.testsIos.testAppsProperties.MultipleWebViews;
import com.connectivity.utils.RunMode;
import com.connectivity.utils.TestUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

public abstract class BaseHybrid extends BasicIosAppium {

    protected static final String URL_1 = "http://www.nxc.co.il/ConnectivityTests/findBy/elem.html";
    protected static final String XPATH_URL_FIELD_1 = "//*[@name='address1']";
    protected static final String XPATH_GO_BTN_1 = "//*[@name='button_navigate1']";
    protected static final String XPATH_EXPECTED_WEB_1 = "//b";
    protected static final String TITLE_EXPECTED_WEB_1 = "OK";
    protected static final String XPATH_EXPECTED_NATIVE_1 = "//*[text()[contains(.,'OK')] or @label='OK']";

    protected static final String URL_2 = "http://www.nxc.co.il/ConnectivityTests/findBy/relativeFind.html";
    protected static final String XPATH_URL_FIELD_2 = "//*[@name='address2']";
    protected static final String XPATH_GO_BTN_2 = "//*[@name='button_navigate2']";
    protected static final String XPATH_EXPECTED_WEB_2 = "//span";
    protected static final String XPATH_EXPECTED_NATIVE_2 = "//*[@label='article']";

    protected WebElement expElement = null;

    protected boolean isInstrumented = true;   // default test param value

    @BeforeClass(alwaysRun = true)
    @Parameters({"deviceId", "automationName", "autoInstrument"})
    public void beforeClass(@Optional("") String deviceId, @Optional("Appium") String automationName, @Optional("false") String autoInstrument, ITestContext context) throws MalformedURLException {

        // add retry for tests using web navigation
        for (ITestNGMethod method : context.getAllTestMethods()) {
                method.setRetryAnalyzer(new Retry());
        }

        if (!Boolean.valueOf(autoInstrument)) isInstrumented = false;

        if (getDevice().getOsVersion().startsWith("13.") && isAppiumFlow()) {
            //TestUtils.skipTest("Pure Appium v1.14 does not support web automation on IOS13, so skipping test...");
        } else if (getDevice().getOsVersion().startsWith("13.") && automationName.equalsIgnoreCase("PerfectoMobile") && !isInstrumented) {
            TestUtils.skipTest("Blocked by: https://perfectomobile.atlassian.net/browse/NP-38042");
        } else if (getDevice().getOsVersion().startsWith("14.") && automationName.equalsIgnoreCase("PerfectoMobile") && !isInstrumented) {
            TestUtils.skipTest("Blocked by: https://perfectomobile.atlassian.net/browse/NP-38042");
        } else if (getDevice().getModel().contains("iPhone-X") && automationName.equalsIgnoreCase("PerfectoMobile") && isInstrumented) {
            TestUtils.skipTest("The test app MultipleWebViews is not adjusted for iPhone-X* models.");
        }


        DesiredCapabilities capabilities = new DesiredCapabilities();

        capabilities.setCapability("app", MultipleWebViews.APP_REPO_LOCATION);
        capabilities.setCapability("bundleId", MultipleWebViews.APP_BUNDLE_ID);
        capabilities.setCapability("autoInstrument", autoInstrument);
        capabilities.setCapability("automationName", automationName);
        capabilities.setCapability("deviceName", deviceId);

        if (isAppiumFlow()) {
            capabilities.setCapability("useAppiumForHybrid", true);
            capabilities.setCapability("fullContextList", true);
            capabilities.setCapability("iOSResign", true);
            //capabilities.setCapability("additionalWebviewBundleIds", Arrays.asList("MultipleWebViews","process-SafariViewService","com.perfectotest.MultipleWebViews", "com.perfectomobile.MultipleWebViews"));
        } else if (TestUtils.validateDeviceOsVersionCompatibility(12.2)) {
            capabilities.setCapability("iOSResign", true);
        }

        createIosDriver(capabilities, MultipleWebViews.APP_NAME);

        if (isAppiumFlow() && !TestUtils.isDeviceUsingXCUITest(getDriver())) {
            TestUtils.skipTest("Hybrid automation not supported by pure Appium on UIAutomation devices, so skipping...");
        }

        /*if (isAppiumFlow() && getDevice().getOsVersion().startsWith("10") && TestUtils.isDeviceUsingXCUITest(getDriver())) {
            TestUtils.skipTest("The pure appium web automation is not working on ios10-PMD devices due to ticket: https://perfectomobile.atlassian.net/browse/NP-41070");
        }*/

        getDriver().manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
        getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

    }

    @Test(groups = {RunMode.HYBRID, RunMode.SMOKE})
    public void basicFlowMultipleWebViews() {

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Enter URL 1 into field 1 of webview 1 and click GO");
        getDriver().context("NATIVE_APP");
        TestUtils.waitSeconds(1);
        getDriver().findElementByXPath(XPATH_URL_FIELD_1).clear();
        getDriver().findElementByXPath(XPATH_URL_FIELD_1).sendKeys(URL_1);
        hideKeyboard();
        TestUtils.waitSeconds(1);
        getDriver().findElementByXPath(XPATH_GO_BTN_1).click();
        TestUtils.waitSeconds(5);
        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Verify expected web element present in NATIVE context before switch to webview");
        getDriver().findElementByXPath(XPATH_EXPECTED_NATIVE_1);

        verifyFirstWebView();

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Enter URL 2 into field 2 of webview 2 and click GO");
        getDriver().context("NATIVE_APP");
        TestUtils.waitSeconds(1);
        getDriver().findElementByXPath(XPATH_URL_FIELD_2).clear();
        getDriver().findElementByXPath(XPATH_URL_FIELD_2).sendKeys(URL_2);
        hideKeyboard();
        TestUtils.waitSeconds(1);
        getDriver().findElementByXPath(XPATH_GO_BTN_2).click();
        TestUtils.waitSeconds(15);

        verifySecondWebView();

    }

    private void hideKeyboard() {

        logger.info("DEVICE ID [" + getDevice().getDeviceId() + "] " + "Checking if keyboard displayed and trying to hide it");
        try {
            getDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            getDriver().findElementByName("shift");
            getDriver().hideKeyboard();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        }
    }

    protected abstract void verifyFirstWebView();

    protected abstract void verifySecondWebView();

    protected abstract Boolean isAppiumFlow();

}
